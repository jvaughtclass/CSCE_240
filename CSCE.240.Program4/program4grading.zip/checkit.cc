// Copyright 2023 bhipp
#include<fstream>
using std::ifstream;
#include<iostream>
using std::cout;
using std::endl;
using std::cin;
using std::getline;
#include<string>
using std::string;
#include<cctype>

int main(int argc, char *argv[]) {
  // executable must be called with a test number 0-1
  if ( argc != 2  || argv[1][0] < '0' || argv[1][0] > '1' ) {
    cout << "Invalid test" << endl;
    return 1;
  }
  // convert the character to an integer
  int which = argv[1][0] - '0';
  string correct[2] = { "correct-testtimeofday.txt",
                        "correct-testtimeinterval.txt" };
  string student[2] = { "student-testtimeofday.txt",
                        "student-testtimeinterval.txt" };
  ifstream correctfile(correct[which]);
  ifstream studentfile(student[which]);

  string correctline, studentline;
  bool match;

  getline(correctfile, correctline);
  getline(studentfile, studentline);
  while ( correctfile.good() && studentfile.good() ) {
    match = correctline == studentline;
    cout << studentline << " : " << (match ? "correct" : "incorrect") << endl;
    getline(correctfile, correctline);
    getline(studentfile, studentline);
  }

  return 0;
}
