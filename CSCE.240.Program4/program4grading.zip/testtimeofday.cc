// Copyright 2023 bhipp
// Initial tests for TimeOfDay class
#include<iostream>
using std::cout;
using std::endl;
#include<fstream>
using std::ifstream;
#include"timeofday.h"

int main() {
  TimeOfDay t1;
  if ( t1.GetHour() != 0 || t1.GetMinute() != 0 || t1.GetSecond() != 0 )
    cout << "Failed default constructor / accessor function test." << endl;
  else
    cout << "Passed default constructor / accessor function test." << endl;

  TimeOfDay t2(17);
  if ( t2.GetHour() != 17 || t2.GetMinute() != 0 || t2.GetSecond() != 0 )
    cout << "Failed TimeOfDay t2(17); / accessor function test." << endl;
  else
    cout << "Passed TimeOfDay t2(17); / accessor function test." << endl;

  TimeOfDay t3(25);
  if ( t3.GetHour() != 0 || t3.GetMinute() != 0 || t3.GetSecond() != 0 )
    cout << "Failed TimeOfDay t3(25); / accessor function test." << endl;
  else
    cout << "Passed TimeOfDay t3(25); / accessor function test." << endl;

  TimeOfDay t4(1, 59);
  if ( t4.GetHour() != 1 || t4.GetMinute() != 59 || t4.GetSecond() != 0 )
    cout << "Failed TimeOfDay t4(1, 59); / accessor function test." << endl;
  else
    cout << "Passed TimeOfDay t4(1, 59); / accessor function test." << endl;

  TimeOfDay t5(-6, -5);
  if ( t5.GetHour() != 0 || t5.GetMinute() != 0 || t5.GetSecond() != 0 )
    cout << "Failed TimeOfDay t5(-6, -5); / accessor function test." << endl;
  else
    cout << "Passed TimeOfDay t5(-6, -5); / accessor function test." << endl;

  TimeOfDay t6(1, 2, 8);
  if ( t6.GetHour() != 1 || t6.GetMinute() != 2 || t6.GetSecond() != 8 )
    cout << "Failed TimeOfDay t6(1, 2, 8); / accessor function test." << endl;
  else
    cout << "Passed TimeOfDay t6(1, 2, 8); / accessor function test." << endl;

  TimeOfDay t7(55, -1, -7);
  if ( t7.GetHour() != 0 || t7.GetMinute() != 0 || t7.GetSecond() != 0 )
    cout << "Failed TimeOfDay t7(55, -1, -7); / accessor function test."
         << endl;
  else
    cout << "Passed TimeOfDay t7(55, -1, -7); / accessor function test."
         << endl;

  t1.SetHour(15);
  t1.SetMinute(6);
  t1.SetSecond(58);
  if ( t1.GetHour() != 15 || t1.GetMinute() != 6 || t1.GetSecond() != 58 )
    cout << "Failed good mutator / accessor function test." << endl;
  else
    cout << "Passed good mutator / accessor function test." << endl;

  t1.SetHour(57);
  t1.SetMinute(82);
  t1.SetSecond(-4);
  if ( t1.GetHour() != 15 || t1.GetMinute() != 6 || t1.GetSecond() != 58 )
    cout << "Failed bad mutator / accessor function test." << endl;
  else
    cout << "Passed bad mutator / accessor function test." << endl;

  t1.Print();
  t1.Print(true);
  t1.Print(true, true);
  t1.Print(false, true);
  t6.Print();
  t6.Print(true, true);
  t6.Print();
  
  return 0;
}

