// Copyright 2023 bhipp
// initial tests for the TimeInterval class
#include<iostream>
using std::cout;
using std::endl;
#include"timeinterval.h"
#include"timeofday.h"

int main() {
  TimeInterval interval1;
  if ( interval1.GetStartTime().GetHour() == 0 &&
       interval1.GetStartTime().GetMinute() == 0 &&
       interval1.GetStartTime().GetSecond() == 0 &&
       interval1.GetEndTime().GetHour() == 0 &&
       interval1.GetEndTime().GetMinute() == 0 &&
       interval1.GetEndTime().GetSecond() == 0 )
    cout << "Passed default constructor test" << endl;
  else
    cout << "Failed default constructor test" << endl;
  interval1.Print(true, true);

  const TimeOfDay t1(23, 57, 7);
  const TimeOfDay t2(23, 58, 1);
  TimeInterval interval2(t1, t2);
  if ( interval2.GetStartTime().GetHour() == 23 &&
       interval2.GetStartTime().GetMinute() == 57 &&
       interval2.GetStartTime().GetSecond() == 7 &&
       interval2.GetEndTime().GetHour() == 23 &&
       interval2.GetEndTime().GetMinute() == 58 &&
       interval2.GetEndTime().GetSecond() == 1 )
    cout << "Passed two TimeOfDay argument constructor test" << endl;
  else
    cout << "Failed two TimeOfDay argument constructor test" << endl;
  interval2.Print(false, true);

  const TimeOfDay t3(0, 4, 7);
  interval1.SetEndTime(t3);
  if ( interval1.GetStartTime().GetHour() == 0 &&
       interval1.GetStartTime().GetMinute() == 0 &&
       interval1.GetStartTime().GetSecond() == 0 &&
       interval1.GetEndTime().GetHour() == 0 &&
       interval1.GetEndTime().GetMinute() == 4 &&
       interval1.GetEndTime().GetSecond() == 7 )
    cout << "Passed first SetEndTime with TimeOfDay argument test" << endl;
  else
    cout << "Failed first SetEndTime with TimeOfDay argument test" << endl;
  interval1.Print(true, true);

  interval2.SetEndTime(t3);
  if ( interval2.GetStartTime().GetHour() == 23 &&
       interval2.GetStartTime().GetMinute() == 57 &&
       interval2.GetStartTime().GetSecond() == 7 &&
       interval2.GetEndTime().GetHour() == 23 &&
       interval2.GetEndTime().GetMinute() == 58 &&
       interval2.GetEndTime().GetSecond() == 1 )
    cout << "Passed second SetEndTime with TimeOfDay argument test" << endl;
  else
    cout << "Failed second SetEndTime with TimeOfDay argument test" << endl;
  interval2.Print();

  interval2.SetEndTime(56, "seconds");
   if ( interval2.GetStartTime().GetHour() == 23 &&
       interval2.GetStartTime().GetMinute() == 57 &&
       interval2.GetStartTime().GetSecond() == 7 &&
       interval2.GetEndTime().GetHour() == 23 &&
       interval2.GetEndTime().GetMinute() == 58 &&
       interval2.GetEndTime().GetSecond() == 3 )
    cout << "Passed SetEndTime(90, \"seconds\") test" << endl;
  else
    cout << "Failed SetEndTime(90, \"seconds\") test" << endl;
  interval2.Print(true, false);

  TimeOfDay t4(22, 7, 5);
  TimeInterval interval3(t4, t1);
  interval3.SetEndTime(188, "minutes");
  if ( interval3.GetStartTime().GetHour() == 22 &&
       interval3.GetStartTime().GetMinute() == 7 &&
       interval3.GetStartTime().GetSecond() == 5 &&
       interval3.GetEndTime().GetHour() == 23 &&
       interval3.GetEndTime().GetMinute() == 57 &&
       interval3.GetEndTime().GetSecond() == 7 )
    cout << "Passed SetEndTime(188, \"minutes\") bad test" << endl;
  else
    cout << "Failed SetEndTime(188, \"minutes\") bad test" << endl;
  interval3.Print(true, true);

  TimeOfDay t5(6, 12, 57);
  TimeInterval interval4(t5, t4);
  interval4.SetEndTime(7388, "seconds");
  if ( interval4.GetStartTime().GetHour() == 6 &&
       interval4.GetStartTime().GetMinute() == 12 &&
       interval4.GetStartTime().GetSecond() == 57 &&
       interval4.GetEndTime().GetHour() == 8 &&
       interval4.GetEndTime().GetMinute() == 16 &&
       interval4.GetEndTime().GetSecond() == 5 )
    cout << "Passed SetEndTime(7388, \"seconds\") good test" << endl;
  else
    cout << "Failed SetEndTime(7388, \"seconds\") good test" << endl;
  interval4.Print(true, true);

  interval4.SetEndTime(2, "hours");
  if ( interval4.GetStartTime().GetHour() == 6 &&
       interval4.GetStartTime().GetMinute() == 12 &&
       interval4.GetStartTime().GetSecond() == 57 &&
       interval4.GetEndTime().GetHour() == 8 &&
       interval4.GetEndTime().GetMinute() == 12 &&
       interval4.GetEndTime().GetSecond() == 57 )
    cout << "Passed SetEndTime(2, \"hours\") test" << endl;
  else
    cout << "Failed SetEndTime(2, \"hours\") test" << endl;
  interval4.Print();

  TimeInterval interval5(t5, t3);
  interval5.SetEndTime(6, "eons");
  if ( interval5.GetStartTime().GetHour() == 6 &&
       interval5.GetStartTime().GetMinute() == 12 &&
       interval5.GetStartTime().GetSecond() == 57 &&
       interval5.GetEndTime().GetHour() == 6 &&
       interval5.GetEndTime().GetMinute() == 12 &&
       interval5.GetEndTime().GetSecond() == 57 )
    cout << "Passed SetEndTime(6, \"eons\") test" << endl;
  else
    cout << "Failed SetEndTime(6, \"eons\") test" << endl;
  interval5.Print();

  interval5.SetStartTime(t3);
  if ( interval5.GetStartTime().GetHour() == 0 &&
       interval5.GetStartTime().GetMinute() == 4 &&
       interval5.GetStartTime().GetSecond() == 7 &&
       interval5.GetEndTime().GetHour() == 6 &&
       interval5.GetEndTime().GetMinute() == 12 &&
       interval5.GetEndTime().GetSecond() == 57 )
    cout << "Passed SetStartTime(t3) test" << endl;
  else
    cout << "Failed SetStartTime(t3) test" << endl;
  interval5.Print(true, true);
  return 0;
}
